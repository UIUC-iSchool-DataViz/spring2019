# This is a Python script that will read the binary file "tornadoData.gda" and 
# translate it into the Houdini-friendly text-based .geo data format.

# To run this code:
# 1. Replace the file paths where marked below to point to the files on your machine.
# 2. Copy the text in this file.
# 3. Open Houdini.
# 4. In the menu, navigate to Windows -> Python Source Editor. Paste in this code and click "Accept".
# 5. In the menu, navigate to Windows -> Python Shell. In the shell, type "hou.session.readTornado()".
# 6. Wait. This will create a Geometry node with the tornado dataset.
# 7. Zoom out (or press the "g" key on your keyboard) to see the full dataset.

# Some general notes about programming in Python:
# * Text that starts with the character "#" is called a "comment" and is ignored when you run the code.
# * "camelCase" is a standard capitalization convention for naming variables.
# * Capitaliation matters! "dataFile" is not the same as "datafile" or "DataFile".
# * Spacing matters! Tabs or spaces at the beginning of a line define the structure of the code.

import struct

def readTornado():

	# Open the data file, for reading binary ("rb"). Choose only one of the two "dataFilePath" lines below.
	dataFilePath = "/home/name/Downloads/bpviz2018/tornadoData.gda"    # Example Mac file path. Modify!
	dataFilePath = "C:\Users\Name\Downloads\bpviz2018\tornadoData.gda" # Example Windows file path. Modify!
	dataFile = open(dataFilePath, "rb") 

	# Open the output file, for writing text ("w"). Choose only one of the two "outFilePath" lines below.
	outFilePath = "/home/name/Downloads/bpviz2018/tornadoData.geo"     # Example Mac file path. Modify!
	outFilePath = "C:\Users\Name\Downloads\bpviz2018\tornadoData.geo"  # Example Mac file path. Modify!
	outFile = open(outFilePath, "w") 

	# Set variables to define the volume resolution, and the number of bytes per data value
	resX = 396
	resY = 440
	resZ = 100
	bytes = 4 

	# Write the .geo file header, saying that we will define 1 point and 1 primitive
	outFile.write("PGEOMETRY V2\n")
	outFile.write("NPoints 1 NPrims 1\n")  
	outFile.write("NPointGroups 0 NPrimGroups 0\n")
	outFile.write("NPointAttrib 0 NVertexAttrib 0 NPrimAttrib 0 NAttrib 0\n\n")

	# Write a single point at x=0, y=0, z=0 to define the center of the volume. Use a weight of 1.
	outFile.write("0 0 0 1\n")

	# Define the volume primitive
	outFile.write("Volume 0 %d 0 0 0 %d 0 0 0 %d -2 %d %d %d constant 0 0 smoke 0 1\n" % (resX, resY, resZ, resX, resY, resZ))

	# Write out the data values
	for z in range(resX):
		for y in range(resY):
			for x in range(resZ):
				data = dataFile.read(bytes)          # Read 4 bytes from the data file
				value = struct.unpack("f", data)[0]  # Unpack the bytes of binary into a number value
				outFile.write("%f " % (value))       # Write the value to our output file

	# End the file
	outFile.write("\nbeginExtra\n")
	outFile.write("endExtra\n")
